<?php

require __DIR__ . '/vendor/autoload.php';

const DEFAULT_URL = 'https://bestbuydata-299f1.firebaseio.com/';
const DEFAULT_TOKEN = '1rzJ8xXydgkijS035441YQ4MUvAOYZ33gROZmYwz';
const DEFAULT_PATH = '/';

$firebase = new \Firebase\FirebaseLib(DEFAULT_URL, DEFAULT_TOKEN);

$request = array(
    "name" => $_GET["requestname"],
    "email" => $_GET["requestemail"],
    "pickup location" => $_GET["requestpickuploc"],
    "pickup datetime" => $_GET["requestpickupdt"],
    "dropoff location" => $_GET["requestdropoffloc"],
    "dropoff datetime" => $_GET["requestdropoffdt"],
    "additional info" => $_GET["requestinfo"]
);


$requests = $firebase->get(DEFAULT_PATH  . '/getnead/request/');

$json=json_decode($requests,true);
if (!empty($requests)) {
  $highest = max(array_keys($json))+1;
}
else{
	$highest=1;
}

if (!empty($_GET["requestemail"])) {
	$firebase->set(DEFAULT_PATH . '/getnead/request/' . $highest . '/', $request);
}
?>
