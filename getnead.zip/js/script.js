/*$(function() {
	$(".btn").click(function() {
		$(".form-signin").toggleClass("form-signin-left");
    $(".form-signup").toggleClass("form-signup-left");
    $(".frame").toggleClass("frame-long");
    $(".signup-inactive").toggleClass("signup-active");
    $(".signin-active").toggleClass("signin-inactive");
    $(".forgot").toggleClass("forgot-left");   
    $(this).removeClass("idle").addClass("active");
	});
});

$(function() {
	$(".btn-signup").click(function() {
  $(".nav").toggleClass("nav-up");
  $(".form-signup-left").toggleClass("form-signup-down");
  $(".success").toggleClass("success-left"); 
  $(".frame").toggleClass("frame-short");
	});
});

$(function() {
	$(".btn-signin").click(function() {
  $(".btn-animate").toggleClass("btn-animate-grow");
  $(".welcome").toggleClass("welcome-left");
  $(".cover-photo").toggleClass("cover-photo-down");
  $(".frame").toggleClass("frame-short");
  $(".profile-photo").toggleClass("profile-photo-down");
  $(".btn-goback").toggleClass("btn-goback-up");
  $(".forgot").toggleClass("forgot-fade");
	});
});
*/
function initialize() {
			
				var pickUpInput = document.getElementById("searchTextField1");
				var pickUpAutoComplete = new google.maps.places.Autocomplete(pickUpInput);
				var dropOffInput = document.getElementById("searchTextField2");
				var dropOffAutoComplete = new google.maps.places.Autocomplete(dropOffInput);
		}
new google.maps.event.addDomListener(window, 'load', initialize);
		
		
$(document).ready(function () {
	$('#notificationformsubmitted').hide();
		$('#contactformsubmitted').hide();
	$('#datetimepicker1').datetimepicker();
	$('#datetimepicker2').datetimepicker();
	

    $(window).scroll(function(){
        var ScrollTop = parseInt($(window).scrollTop());

        if (ScrollTop > 160) {
        	$(".socialTop").hide();
					$(".headerTop").hide();
        }
        else{
        	$(".socialTop").show();
					$(".headerTop").show();
        }
    });
    
    $(".service").hover(function(){
    	$(this).addClass("selected");
    	
    },function(){
    	$(this).removeClass("selected");
    	    });

            $("#notificationform").submit(function(e) {

    	e.preventDefault();
	        $.ajax({
            type: "GET",
            url: "request.php",
            data: $(this).serialize(), // serialize form data
            success: function(data) {

            //   $('#notificationform').hide();
              // $('.quoteFormContainer p').hide();
               $('#notificationformsubmitted').show();
            },
            error: function() {
				//$('.quoteFormContainer p').hide();
				//$('#notificationform').hide();
            }
        });
        		$('#notificationform').find("input[type=text],input[type=email], textarea").val("");
	  });
	  
            $("#contact-us").submit(function(e) {
			
    	e.preventDefault();
	        $.ajax({
            type: "GET",
            url: "contact.php",
            data: $(this).serialize(), // serialize form data
            success: function(data) {

               //$('#contactform').hide();
               //$('.quoteFormContainer p').hide();
               $('#contactformsubmitted').show();
            },
            error: function() {
				//$('.quoteFormContainer p').hide();
				//$('#contactform').hide();
            }
        });
		$('#contact-us').find("input[type=text],input[type=email], textarea").val("");
	  });
});
