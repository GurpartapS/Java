<!DOCTYPE html>

<html lang="en" class="no-js">
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8"/>
        <title>NEAD | Non-Emergency Ambulance Dispatch Service</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport"/>
        <meta content="" name="description"/>
        <meta content="" name="author"/>
<meta name="viewport" content="width=device-width, initial-scale = 1.0, maximum-scale=1.0, user-scalable=no" />
        <!-- GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Hind:300,400,500,600,700" rel="stylesheet" type="text/css">
        <link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css"/>
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>

        <!-- PAGE LEVEL PLUGIN STYLES -->
        <link href="css/animate.css" rel="stylesheet">
        <link href="vendor/swiper/css/swiper.min.css" rel="stylesheet" type="text/css"/>
        <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css"/>

        <!-- THEME STYLES -->
        <link href="css/layout.min.css" rel="stylesheet" type="text/css"/>

        <!-- Favicon -->
        <link rel="shortcut icon" href="favicon.ico"/>
        
				<link href="css/style.css" rel="stylesheet">
				<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    </head>
    <!-- END HEAD -->

    <!-- BODY -->
    <body id="body" data-spy="scroll" data-target=".header">

        <!--========== HEADER ==========-->
        <header class="header navbar-fixed-top">
        
        	<div class="headerTop hidden-xs" >
			<i class="fa fa-facebook socialcon" aria-hidden="true" style="color:#17bed2;float:right;margin-right:20px;font-size:20px;"></i>	
          <i class="fa fa-twitter socialIcon" aria-hidden="true" style="color:#17bed2;float:right;margin-right:20px;font-size:20px;"></i>	
          
					<i class="fa fa-instagram socialIcon" aria-hidden="true" style="color:#17bed2;float:right;margin-right:20px;font-size:20px;margin-left:40px;"></i>	
			<button class="btn-signin">Be a member</button>          
 			
 				<p style="margin-right:-28%;" >1800-GET-NEAD</p>
           
           <i  class="glyphicon glyphicon-earphone"></i>	
           </div>
            <!-- Navbar -->
            <nav class="navbar" role="navigation">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="menu-container js_nav-item">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".nav-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="toggle-icon"></span>
                        </button>

                        <!-- Logo -->
                        <div class="logo">
                            <a class="logo-wrap" href="#body">
                                <img class="logo-img logo-img-main" src="img/logo.png" alt="Asentus Logo">
                                <img class="logo-img logo-img-active" src="img/logo-dark.png" alt="Asentus Logo">
                            </a>
                        </div>
                        <!-- End Logo -->
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse nav-collapse">
                        <div class="menu-container">
                            <ul class="nav navbar-nav navbar-nav-right">
                                <li class="js_nav-item nav-item"><a class="nav-item-child nav-item-hover" href="#body">Home</a></li>
                                <li class="js_nav-item nav-item"><a class="nav-item-child nav-item-hover" href="#service-container">Services</a></li>
                                <li class="js_nav-item nav-item"><a class="nav-item-child nav-item-hover" href="#products-container">Why Nead</a></li>
                                <li class="js_nav-item nav-item"><a class="nav-item-child nav-item-hover" href="#about-container">About</a></li>
                                <li class="js_nav-item nav-item"><a class="nav-item-child nav-item-hover" href="#work-container">Customers</a></li>
                                <li class="js_nav-item nav-item"><a class="nav-item-child nav-item-hover" href="#contact-form">Contact</a></li>
																
                            </ul>
                        </div>
                    </div>
                    <!-- End Navbar Collapse -->
                </div>
            </nav>
            <!-- Navbar -->
        </header>
        <!--========== END HEADER ==========-->

        <!--========== SLIDER ==========-->
        <div class="promo-block" >
        	<div class="row" >
        			<div class="col-md-7 col-xs-1"></div>
        			
										<div class="col-md-3 col-xs-10" >
	                    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>

<div class="quoteFormContainer">
  <div class="frame">
    <div class="nav">
      
        <p style="font-size:175%;">Request a Quote</p>
       
      
    </div>
    <div ng-app ng-init="checked = false">

				  <form class="form-signin" id="notificationform" action="#" method="GET" name="form">
	
    <div class='input-group date' id='datetimepickerinput' >
                    <span class="input-group-addon" style="border-radius:5px 0px 0px 5px; z-index:+2;">
                        <span class="glyphicon glyphicon-user"></span>
                    </span>
                    <input type='text' class="form-control" name="requestname" style="border-radius:0px 5px 5px 0px;z-index:+1;height:38px;" placeholder="Name" required />
                </div>
                 <div class='input-group date' id='datetimepickerinput' >
                    <span class="input-group-addon" style="border-radius:5px 0px 0px 5px; z-index:+2;">
                        <span class="glyphicon glyphicon-envelope"></span>
                    </span>
                    <input type='email' class="form-control" name="requestemail" style="border-radius:0px 5px 5px 0px;z-index:+1;height:38px;" placeholder="Email" required/>
                </div>
                 <div class='input-group date' id='datetimepickerinput' >
                    <span class="input-group-addon" style="border-radius:5px 0px 0px 5px; z-index:+2;">
                        <span class="glyphicon glyphicon-map-marker"></span>
                    </span>
                     
                    <input type='text' class="form-control" name="requestpickuploc" id="searchTextField1" style="border-radius:0px 5px 5px 0px;z-index:+1;height:38px;" placeholder="Pick-Up Location"  required/>
                </div>
                 <!--<div class='input-group date' id='datetimepicker1' >
                    <span class="input-group-addon" style="border-radius:5px 0px 0px 5px; z-index:+2;">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                    <input type='text' class="form-control" name="requestpickupdt" style="border-radius:0px 5px 5px 0px;z-index:+1;height:38.5px;" placeholder="Pick-Up Date/Time" required/>
                </div>-->
                <div class='input-group date' id='datetimepickerinput' >
                    <span class="input-group-addon" style="border-radius:5px 0px 0px 5px; z-index:+2;">
                        <span class="glyphicon glyphicon-map-marker"></span>
                    </span>
                    <input type='text' class="form-control" name="requestdropoffloc" id="searchTextField2" style="border-radius:0px 5px 5px 0px;z-index:+1;height:38px;" placeholder="Drop-Off Location" required/>
                </div>
        	<!--<div class='input-group date' id='datetimepicker2' >
                    <span class="input-group-addon" style="border-radius:5px 0px 0px 5px; z-index:+2;">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                    <input type='text' class="form-control" name="requestdropoffdt" style="border-radius:0px 5px 5px 0px;z-index:+1;height:38.5px;" placeholder="Drop-Up Date/Time" required/>
                </div>
          -->
                
          <textarea class="form-styling" type="text" name="requestinfo" style="z-index:+1;width:100%" placeholder="Additional Information"></textarea>
		    <div id="notificationformsubmitted" >
			<h6 style="color:white;">Thanks. We will get in touch with you soon!!</h6>
		    </div>          
            <button class="btn-signin" type="submit" style="color:#17bed2;background:#ffffff;font-size:90%;padding-top:-2%;">Request Now</button>
          </form>
      
            <div  class="success">
              <svg width="270" height="270" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
       viewBox="0 0 60 60" id="check" ng-class="checked ? 'checked' : ''">
                 <path fill="#ffffff" d="M40.61,23.03L26.67,36.97L13.495,23.788c-1.146-1.147-1.359-2.936-0.504-4.314
                  c3.894-6.28,11.169-10.243,19.283-9.348c9.258,1.021,16.694,8.542,17.622,17.81c1.232,12.295-8.683,22.607-20.849,22.042
                  c-9.9-0.46-18.128-8.344-18.972-18.218c-0.292-3.416,0.276-6.673,1.51-9.578" />
                <div class="successtext">
                   <p> Thanks for signing up! Check your email for confirmation.</p>
                </div>
             </div>
      </div>
      
   
      
  </div>
    
  <a id="refresh" value="Refresh" onClick="history.go()">
    <svg class="refreshicon"   version="1.1" id="Capa_1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
         width="25px" height="25px" viewBox="0 0 322.447 322.447" style="enable-background:new 0 0 322.447 322.447;"
         xml:space="preserve">
         <path  d="M321.832,230.327c-2.133-6.565-9.184-10.154-15.75-8.025l-16.254,5.281C299.785,206.991,305,184.347,305,161.224
                c0-84.089-68.41-152.5-152.5-152.5C68.411,8.724,0,77.135,0,161.224s68.411,152.5,152.5,152.5c6.903,0,12.5-5.597,12.5-12.5
                c0-6.902-5.597-12.5-12.5-12.5c-70.304,0-127.5-57.195-127.5-127.5c0-70.304,57.196-127.5,127.5-127.5
                c70.305,0,127.5,57.196,127.5,127.5c0,19.372-4.371,38.337-12.723,55.568l-5.553-17.096c-2.133-6.564-9.186-10.156-15.75-8.025
                c-6.566,2.134-10.16,9.186-8.027,15.751l14.74,45.368c1.715,5.283,6.615,8.642,11.885,8.642c1.279,0,2.582-0.198,3.865-0.614
                l45.369-14.738C320.371,243.946,323.965,236.895,321.832,230.327z"/>
    </svg>
  </a>
</div>
                    </div>
                </div>
                <!--<a class="js_popup-youtube btn-theme btn-theme-md btn-white-bg text-uppercase" href="https://www.youtube.com/watch?v=0qisGSwZym4" title="Intro Video"><i class="btn-icon icon-control-play"></i> Watch Intro Video</a>-->
           <!-- <div class="container">
                    
            </div>-->
        </div>
        <div class="col-xs-1"></div>
        <!--========== SLIDER ==========-->

        <!--========== PAGE LAYOUT ==========-->
        
            <div id="service">
            	
            <div class="bg-color-sky-light" data-auto-height="true" >
            	
                <div class="content-lg container" >
                	 <div class="row text-center margin-b-40">
                    <div class="col-sm-6 col-sm-offset-3" id="service-container" >
                        <h2 style="color:#17bed2">Our Services</h2	>
                        <p>Non-Emergency Service Dispatch is one of the greatest service providers in north america</p>
                    </div>
                </div>
                    <div class="row row-space-2 margin-b-4" >
                        <div class="col-sm-4 sm-margin-b-4">
                            <div class="service wow fadeInDown" data-height="height">
                                <div class="service-element">
                                    <i class="service-icon icon-heart"></i>
                                </div>
                                <div class="service-info">
                                    <h3>Ambulance</h3>
                                    <p class="margin-b-5">Access to largest fleet of safe, most up-kept and updated vehicles industry wide</p>
                                </div>
                                <a href="#" class="content-wrapper-link"></a>    
                            </div>
                        </div>
                        <div class="col-sm-4 sm-margin-b-4">
                            <div class="service wow fadeInDown" data-height="height" data-wow-duration=".3" data-wow-delay=".1s">
                                <div class="service-element">
                                    <i class="service-icon icon-screen-tablet"></i>
                                </div>
                                <div class="service-info">
                                    <h3 class="">Bedside to Bedside</h3>
                                    <p class="margin-b-5">Highly trained staff will ensure that the patient is transfered from bedside to bedside</p>
                                </div>
                                <a href="#" class="content-wrapper-link"></a>    
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="service wow fadeInDown" data-height="height">
                                <div class="service-element">
                                    <i class="service-icon icon-notebook"></i>
                                </div>
                                <div class="service-info">
                                    <h3>Advance Booking</h3>
                                    <p class="margin-b-5">Bookings may be short notice calls or scheduled in advance>
                                </div>
                                <a href="#" class="content-wrapper-link"></a>    
                            </div>
                        </div>
                    </div>
                    <!--// end row -->

                    <div class="row row-space-2">
                        <div class="col-sm-4 sm-margin-b-4">
                            <div class="service wow fadeInDown" data-height="height">
                                <div class="service-element">
                                    <i class="service-icon icon-notebook"></i>
                                </div>
                                <div class="service-info">
                                    <h3>Strair Chairs & Stretcher</h3>
                                    <p class="margin-b-5">Skilled staff will ensure safe transport of patients using chairlifts and stretchers</p>
                                </div>
                                <a href="#" class="content-wrapper-link"></a>    
                            </div>
                        </div>
                        <div class="col-sm-4 sm-margin-b-4">
                            <div class="service wow fadeInDown" data-height="height">
                                <div class="service-element">
                                    <i class="service-icon icon-speedometer"></i>
                                </div>
                                <div class="service-info">
                                    <h3>Oxygen & First Aid</h3>
                                    <p class="margin-b-5">Ambulances are equpped with oxygen and first aid equipment</p>
                                </div>
                                <a href="#" class="content-wrapper-link"></a>    
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="service wow fadeInDown" data-height="height">
                                <div class="service-element">
                                    <i class="service-icon icon-rocket"></i>
                                </div>
                                <div class="service-info">
                                    <h3>Coming Soon - Location Tracker</h3>
                                    <p class="margin-b-5">NEAD will soon be introducing live location tracker while your loved ones travel with us to their detination</p>
                                </div>
                                <a href="#" class="content-wrapper-link"></a>    
                            </div>
                        </div>
                    </div>
                    <!--// end row -->
                </div>
            </div>
        </div>
        
        <!-- Products -->
        <div id="products">
            <div class="container content-lg">
                <div class="row text-center margin-b-40">
                    <div class="col-sm-6 col-sm-offset-3" id="products-container">
                        <h2 style="color:#17bed2">Why Nead</h2	>
                        <p>Non-Emergency Service Dispatch is one of the greatest service providers in north america.</p>
                    </div>
                </div>
                <!--// end row -->

                <div class="row">
                    <!-- Latest Products -->
                    <div class="col-sm-4 sm-margin-b-50">
                        <div class="margin-b-20">
                            <i class="service-icon icon-clock" data-wow-duration="2" data-wow-delay="1s"></i>
                        </div>
                        <h4><a href="#">24x7 Service</a> </h4>
                        <p>Sample text paragraph to be added here for more information</p>
                        <a class="link" href="#">Read More</a>
                    </div>
                    <!-- End Latest Products -->

                    <!-- Latest Products -->
                    <div class="col-sm-4 sm-margin-b-50">
                        <div class="margin-b-20">
                           <i class="service-icon icon-people" data-wow-duration="2" data-wow-delay="1s"></i>
                        </div>
                        <h4><a href="#">Largest Fleet</a> </h4>
                        <p>Sample text paragraph to be added here for more information</p>
                        <a class="link" href="#">Read More</a>
                    </div>
                    <!-- End Latest Products -->

                    <!-- Latest Products -->
                    <div class="col-sm-4 sm-margin-b-50">
                        <div class="margin-b-20">
                           <i class="service-icon icon-paper-plane" data-wow-duration="2" data-wow-delay="1s"></i>
                        </div>
                        <h4><a href="#">Fastest Service</a></h4>
                        <p>Sample text paragraph to be added here for more information</p>
                        <a class="link" href="#">Read More</a>
                    </div>
                    <!-- End Latest Products -->
                </div>
                <!--// end row -->
                       <div class="row" style="margin-top:5%;">
                    <!-- Latest Products -->
                    <div class="col-sm-4 sm-margin-b-50">
                        <div class="margin-b-20">
                            <i class="service-icon icon-badge" data-wow-duration="2" data-wow-delay="1s"></i>
                        </div>
                        <h4><a href="#">Quality Customer Service</a> </h4>
                        <p>Sample text paragraph to be added here for more information</p>
                        <a class="link" href="#">Read More</a>
                    </div>
                    <!-- End Latest Products -->

                    <!-- Latest Products -->
                    <div class="col-sm-4 sm-margin-b-50">
                        <div class="margin-b-20">
                            <i class="service-icon icon-wallet" data-wow-duration="2" data-wow-delay="1s"></i>
                        </div>
                        <h4><a href="#">Cost Effective</a> </h4>
                        <p>Sample text paragraph to be added here for more information</p>
                        <a class="link" href="#">Read More</a>
                    </div>
                    <!-- End Latest Products -->

                    <!-- Latest Products -->
                    <div class="col-sm-4 sm-margin-b-50">
                        <div class="margin-b-20">
                            <i class="service-icon icon-screen-tablet" data-wow-duration="2" data-wow-delay="1s"></i>
                        </div>
                        <h4><a href="#">Besdside to Bedside Service</a> </h4>
                        <p>Sample text paragraph to be added here for more information</p>
                        <a class="link" href="#">Read More</a>
                    </div>
                    <!-- End Latest Products -->
                </div>
            </div>
<!--
            <div class="container-full-width">
                <div class="row row-space-2">
                    <div class="col-sm-6 sm-margin-b-4">
                        <img class="img-responsive" src="img/970x647/01.jpg" alt="Image">
                    </div>
                    <div class="col-sm-6">
                        <img class="img-responsive" src="img/970x647/03.jpg" alt="Image">
                    </div>
                </div>
                <!--// end row -->
            </div>
            
        </div>
        <!-- End Products -->
        
        <!-- Promo Banner -->
        <div id="about" class="promo-banner">
            <div class="container-sm content-lg" id="about-container">
                <h2 class="promo-banner-title" style="font-size:200%">Non-Emergency Ambulance Dispatch </h2><br>
                <p class="promo-banner-text" style="font-size:120%">We are a dispatcher offering Non Emergency Ambulance Transportation services to the entire province of Ontario. Our call centre is open 24 hours per day, seven days per week to serve our customers in the most effective way. We are a dispatcher offering Non Emergency Ambulance Transportation services to the entire province of Ontario. Our call centre is open 24 hours per day, seven days per week to serve our customers in the most effective way. </p>
            </div>
        </div><br><br>
        <!-- End Promo Banner -->
<!-- Contact -->
        <div id="contact">
        	<div class="row text-center margin-b-40">
                    <div class="col-sm-6 col-sm-offset-3" >
                        <h2 style="color:#17bed2">Our Geographical Coverage</h2	>
                        <p>Non-Emergency Service Dispatch is one of the greatest service providers in north america.</p>
                    </div>
                </div>
            <!-- Google Map -->
		<div id="map" class="to-animate"></div>
            <!-- End Google Map -->
        </div>
        <!-- Service -->
    
        <!-- End Service -->

<!--
    
        <div id="pricing">
            <div class="bg-color-sky-light">
                <div class="content-lg container">
                    <div class="row row-space-2">
                        <div class="col-sm-4 sm-margin-b-4">
    
                            <div class="pricing">
                                <div class="margin-b-30">
                                    <i class="pricing-icon icon-chemistry"></i>
                                    <h3>Starter Kit <span> - $</span> 49</h3>
                                    <p>Sample text paragraph to be added here for more information</p>
                                </div>
                                <ul class="list-unstyled pricing-list margin-b-50">
                                    <li class="pricing-list-item">Basic Features</li>
                                    <li class="pricing-list-item">Up to 5 products</li>
                                    <li class="pricing-list-item">50 Users Panels</li>
                                </ul>
                                <a href="pricing.html" class="btn-theme btn-theme-sm btn-default-bg text-uppercase">Choose</a>
                            </div>
    
                        </div>
                        <div class="col-sm-4 sm-margin-b-4">
    
                            <div class="pricing pricing-active">
                                <div class="margin-b-30">
                                    <i class="pricing-icon icon-badge"></i>
                                    <h3>Professional <span> - $</span> 149</h3>
                                    <p>Sample text paragraph to be added here for more information</p>
                                </div>
                                <ul class="list-unstyled pricing-list margin-b-50">
                                    <li class="pricing-list-item">Basic Features</li>
                                    <li class="pricing-list-item">Up to 100 products</li>
                                    <li class="pricing-list-item">100 Users Panels</li>
                                </ul>
                                <a href="pricing.html" class="btn-theme btn-theme-sm btn-default-bg text-uppercase">Choose</a>
                            </div>
    
                        </div>
                        <div class="col-sm-4">
    
                            <div class="pricing">
                                <div class="margin-b-30">
                                    <i class="pricing-icon icon-shield"></i>
                                    <h3>Advanced <span> - $</span> 249</h3>
                                    <p>Sample text paragraph to be added here for more information</p>
                                </div>
                                <ul class="list-unstyled pricing-list margin-b-50">
                                    <li class="pricing-list-item">Extended Features</li>
                                    <li class="pricing-list-item">Unlimited products</li>
                                    <li class="pricing-list-item">Unlimited Users Panels</li>
                                </ul>
                                <a href="pricing.html" class="btn-theme btn-theme-sm btn-default-bg text-uppercase">Choose</a>
                            </div>
    
                        </div>
                    </div>
    
                </div>
            </div>
        </div>
    
-->
         <!-- End Contact -->
        <!--========== END PAGE LAYOUT ==========-->

 <!-- Work -->
        <div id="work">
            <div class="content-md container">
            		<div class="row text-center margin-b-40">
                    <div class="col-sm-6 col-sm-offset-3" id="work-container">
                        <h2 style="color:#17bed2">We believe in your happiness</h2	>
                        <p>NEAD takes pride in serving those in need. Our mission is to safely transport our patients and customers in a manner consistent with our core values of excellence in patient care, integrity, customer service and first and foremost safety</p>
                    </div>
                </div>
                <!-- Masonry Grid -->
                <div class="masonry-grid row row-space-2">
                    <div class="masonry-grid-sizer col-xs-6 col-sm-6 col-md-1"></div>
                    <div class="masonry-grid-item col-xs-12 col-sm-6 col-md-8 margin-b-4" >
                        <!-- Work -->
                        <div class="work work-popup-trigger">
                            <div class="work-overlay">
                                <img class="full-width img-responsive" src="img/800x400/01.jpg" alt="Portfolio Image">
                            </div>
                            <div class="work-popup-overlay">
                                <div class="work-popup-content">
                                    <a href="javascript:void(0);" class="work-popup-close">Hide</a>
                                    <div class="margin-b-30">
                                        <h3 class="margin-b-5" style="color:#17bed2">Sample Story Title</h3>
                                        <span>Story subtitle</span>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-8 work-popup-content-divider sm-margin-b-20">
                                            <div class="margin-t-10 sm-margin-t-0">
                                                <p>Story paragraph 1</p>
                                                <p>Story paragraph 2</p>
                                                <ul class="list-inline work-popup-tag">
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 1,</a></li>
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 2,</a></li>
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 3</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="margin-t-10 sm-margin-t-0">
                                                <p class="margin-b-5"><strong>Story Date:</strong> Date</p>
                                                <p class="margin-b-5"><strong>Story Location:</strong> Location</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Work -->
                    </div>
                    
                    
                    
                    <div class="masonry-grid-item col-xs-12 col-sm-6 col-md-4 margin-b-4">
                        <!-- Work -->
                        <div class="work work-popup-trigger">
                            <div class="work-overlay">
                                <img class="full-width img-responsive" src="img/397x400/01.jpg" alt="Portfolio Image">
                            </div>
                         <div class="work-popup-overlay">
                                <div class="work-popup-content">
                                    <a href="javascript:void(0);" class="work-popup-close">Hide</a>
                                    <div class="margin-b-30">
                                        <h3 class="margin-b-5" style="color:#17bed2">Sample Story Title</h3>
                                        <span>Story subtitle</span>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-8 work-popup-content-divider sm-margin-b-20">
                                            <div class="margin-t-10 sm-margin-t-0">
                                                <p>Story paragraph 1</p>
                                                <p>Story paragraph 2</p>
                                                <ul class="list-inline work-popup-tag">
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 1,</a></li>
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 2,</a></li>
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 3</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="margin-t-10 sm-margin-t-0">
                                                <p class="margin-b-5"><strong>Story Date:</strong> Date</p>
                                                <p class="margin-b-5"><strong>Story Location:</strong> Location</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Work -->
                    </div>
                    <div class="masonry-grid-item col-xs-12 col-sm-6 col-md-4 md-margin-b-4">
                        <!-- Work -->
                        <div class="work work-popup-trigger">
                            <div class="work-overlay">
                                <img class="full-width img-responsive" src="img/397x300/01.jpg" alt="Portfolio Image">
                            </div>
                        <div class="work-popup-overlay">
                                <div class="work-popup-content">
                                    <a href="javascript:void(0);" class="work-popup-close">Hide</a>
                                    <div class="margin-b-30">
                                        <h3 class="margin-b-5" style="color:#17bed2">Sample Story Title</h3>
                                        <span>Story subtitle</span>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-8 work-popup-content-divider sm-margin-b-20">
                                            <div class="margin-t-10 sm-margin-t-0">
                                                <p>Story paragraph 1</p>
                                                <p>Story paragraph 2</p>
                                                <ul class="list-inline work-popup-tag">
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 1,</a></li>
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 2,</a></li>
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 3</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="margin-t-10 sm-margin-t-0">
                                                <p class="margin-b-5"><strong>Story Date:</strong> Date</p>
                                                <p class="margin-b-5"><strong>Story Location:</strong> Location</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Work -->
                    </div>
                    <div class="masonry-grid-item col-xs-12 col-sm-6 col-md-4 md-margin-b-4">
                        <!-- Work -->
                        <div class="work work-popup-trigger">
                            <div class="work-overlay">
                                <img class="full-width img-responsive" src="img/397x300/04.jpg" alt="Portfolio Image">
                            </div>
                        <div class="work-popup-overlay">
                                <div class="work-popup-content">
                                    <a href="javascript:void(0);" class="work-popup-close">Hide</a>
                                    <div class="margin-b-30">
                                        <h3 class="margin-b-5" style="color:#17bed2">Sample Story Title</h3>
                                        <span>Story subtitle</span>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-8 work-popup-content-divider sm-margin-b-20">
                                            <div class="margin-t-10 sm-margin-t-0">
                                                <p>Story paragraph 1</p>
                                                <p>Story paragraph 2</p>
                                                <ul class="list-inline work-popup-tag">
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 1,</a></li>
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 2,</a></li>
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 3</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="margin-t-10 sm-margin-t-0">
                                                <p class="margin-b-5"><strong>Story Date:</strong> Date</p>
                                                <p class="margin-b-5"><strong>Story Location:</strong> Location</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Work -->
                    </div>
                    <div class="masonry-grid-item col-xs-12 col-sm-6 col-md-4 md-margin-b-4">
                        <!-- Work -->
                        <div class="work work-popup-trigger">
                            <div class="work-overlay">
                                <img class="full-width img-responsive" src="img/397x300/02.jpg" alt="Portfolio Image">
                            </div>
                      <div class="work-popup-overlay">
                                <div class="work-popup-content">
                                    <a href="javascript:void(0);" class="work-popup-close">Hide</a>
                                    <div class="margin-b-30">
                                        <h3 class="margin-b-5" style="color:#17bed2">Sample Story Title</h3>
                                        <span>Story subtitle</span>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-8 work-popup-content-divider sm-margin-b-20">
                                            <div class="margin-t-10 sm-margin-t-0">
                                                <p>Story paragraph 1</p>
                                                <p>Story paragraph 2</p>
                                                <ul class="list-inline work-popup-tag">
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 1,</a></li>
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 2,</a></li>
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 3</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="margin-t-10 sm-margin-t-0">
                                                <p class="margin-b-5"><strong>Story Date:</strong> Date</p>
                                                <p class="margin-b-5"><strong>Story Location:</strong> Location</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Work -->
                    </div>
                    <div class="masonry-grid-item col-xs-12 col-sm-6 col-md-4">
                        <!-- Work -->
                        <div class="work work-popup-trigger">
                            <div class="work-overlay">
                                <img class="full-width img-responsive" src="img/397x300/03.jpg" alt="Portfolio Image">
                            </div>
                          <div class="work-popup-overlay">
                                <div class="work-popup-content">
                                    <a href="javascript:void(0);" class="work-popup-close">Hide</a>
                                    <div class="margin-b-30">
                                        <h3 class="margin-b-5" style="color:#17bed2">Sample Story Title</h3>
                                        <span>Story subtitle</span>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-8 work-popup-content-divider sm-margin-b-20">
                                            <div class="margin-t-10 sm-margin-t-0">
                                                <p>Story paragraph 1</p>
                                                <p>Story paragraph 2</p>
                                                <ul class="list-inline work-popup-tag">
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 1,</a></li>
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 2,</a></li>
                                                    <li class="work-popup-tag-item"><a class="work-popup-tag-link" href="#">Story Link 3</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="margin-t-10 sm-margin-t-0">
                                                <p class="margin-b-5"><strong>Story Date:</strong> Date</p>
                                                <p class="margin-b-5"><strong>Story Location:</strong> Location</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Work -->
                    </div>
                </div>
                <!-- End Masonry Grid -->
            </div>
        </div>
        <!-- End Work -->
<!-- Testimonials -->
        <div class="content-md container">
            <div class="row">
                <div class="col-sm-9">
                    <h2 style="color:black;font-size:125%;">Check out what our customers have to say about us.</h2>

                    <!-- Swiper Testimonials -->
                    <div class="swiper-slider swiper-testimonials">
                        <!-- Swiper Wrapper -->
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <blockquote class="blockquote">
                                    <div class="margin-b-20">
                                        Sample customer review paragraph 1.
                                    </div>
                                    <div class="margin-b-20">
                                        Sample customer review paragraph 2.
                                    </div>
                                    <p><span class="fweight-700 color-link">Customer Name</span>, Customer Information</p>
                                </blockquote>
                            </div>
                            <div class="swiper-slide">
                                <blockquote class="blockquote">
                                    <div class="margin-b-20">
                                        Sample customer review paragraph 1.
                                    </div>
                                    <div class="margin-b-20">
                                        Sample customer review paragraph 2.
                                    </div>
                                    <p><span class="fweight-700 color-link">Customer Name</span>, Customer Information</p>
                                </blockquote>
                            </div>
                        </div>
                        <!-- End Swiper Wrapper -->

                        <!-- Pagination -->
                        <div class="swiper-testimonials-pagination"></div>
                    </div>
                    <!-- End Swiper Testimonials -->
                </div>
            </div>
            <!--// end row -->
        </div>
       
<div class="inner contact" id="contact-form">
	 <div class="row text-center margin-b-40">
                    <div class="col-sm-6 col-sm-offset-3">
                        <h2 style="color:#17bed2">we would love to hear from you</h2	>
                        <p>NEAD is always looking for active feedback to help improve our service and products.</p>
                    </div>
                </div>
                <!-- Form Area -->
                <div class="contact-form">

				    <div class="row" style="margin-bottom:5%;">

				    					    	<div class="col-xs-12 col-md-4 col-md-offset-2" style="text-align:center"><i class="fa fa-phone socialIcon" aria-hidden="true" style="color:#17bed2;font-size:120%;padding:5%;text-align:center;margin-top:-1%;"><b style="font-size:120%;color:grey">&nbsp;&nbsp;1800-GET-NEAD</b></i>	</div>
				    					    		<div class="col-xs-12 col-md-4" style="text-align:center""><i class="fa fa-envelope socialIcon" aria-hidden="true" style="color:#17bed2;font-size:120%;padding:5%;text-align:center;margin-top:-3%;"><b style="font-size:120%;color:grey">&nbsp;&nbsp;info@getnead.ca</b></i>	</div>

				    </div>
				    
			                <div id="contactformsubmitted" >
					<h5 style="color:#17bed2;text-align:center;">Thanks. We will get in touch with you soon!!</h5>
				    </div>
                    <!-- Form -->
                    <form id="contact-us" method="post" action="#">
                        <!-- Left Inputs -->
                        <div class="col-md-6 col-xs-12 wow animated slideInLeft" data-wow-delay=".5s">
                            <!-- Name -->
                            <input type="text" name="name" id="name" required="required" class="form" placeholder="Name" />
                            <!-- Email -->
                            <input type="email" name="mail" id="mail" required="required" class="form" placeholder="Email" />
                            <!-- Subject -->
                            <input type="text" name="subject" id="subject" required="required" class="form" placeholder="Subject" />
                        </div><!-- End Left Inputs -->
                        <!-- Right Inputs -->
                        <div class="col-md-6 col-xs-12 wow animated slideInRight" data-wow-delay=".5s">
                            <!-- Message -->
                            <textarea name="message" id="message" class="form textarea"  placeholder="Message"></textarea>
                        </div><!-- End Right Inputs -->
                        <!-- Bottom Submit -->
                        <div class="relative fullwidth col-xs-12">
                            <!-- Send Button -->
                            <button type="submit" id="submit" name="submit" class="form-btn semibold">Send Message</button> 
                        </div><!-- End Bottom Submit -->
                        <!-- Clear -->
                        <div class="clear"></div>
                    </form>

                    <!-- Your Mail Message -->
                    <div class="mail-message-area">
                        <!-- Message -->
                        <div class="alert gray-bg mail-message not-visible-message">
                            <strong>Thank You !</strong> Your email has been delivered.
                        </div>
                    </div>

                </div><!-- End Contact Form Area -->
            </div><!-- End Inner -->
        <!--========== FOOTER ==========-->
        <footer class="footer">
            <!-- Links -->
            <div class="section-seperator">
                <div class="content-md container">
                    <div class="row">
                    	<div class="col-md-2 col-xs-4">
                        <img class="footer-logo" src="img/logo-dark.png" alt="Aironepage Logo">
                    </div>
                    
                        <div class="col-md-1 col-xs-3 sm-margin-b-30">
                    	        <!-- List -->
                            <ul class="list-unstyled footer-list">
                                <li class="footer-list-item"><a href="#">Home</a></li>
                                <li class="footer-list-item"><a href="#">About</a></li>
                                <li class="footer-list-item"><a href="#">Work</a></li>
                                <li class="footer-list-item"><a href="#">Contact</a></li>
                            </ul>
                            <!-- End List -->
                        </div>
                        <div class="col-md-1">	</div>
                        <div class="col-md-1 col-xs-3 sm-margin-b-30">
                            <!-- List -->
                            
                            
                            
                            <ul class="list-unstyled footer-list">
                                <li class="footer-list-item"><a href="#">Twitter</a></li>
                                <li class="footer-list-item"><a href="#">Facebook</a></li>
                                <li class="footer-list-item"><a href="#">Instagram</a></li>
                                <li class="footer-list-item"><a href="#">YouTube</a></li>
                            </ul>
                            <!-- End List -->
                        </div>
                        <div class="col-md-2 hidden-xs">	</div>
                        <div class="col-md-3 hidden-sm hidden-xs">
                            <!-- List -->
                            <ul class="list-unstyled footer-list">
                                <li class="footer-list-item"><a href="#">Subscribe to Our Newsletter</a></li>
                                <li class="footer-list-item"><a href="#">Privacy Policy</a></li><br>
                                <li class="footer-list-item"><a href="#">Terms &amp; Conditions</a></li>
                            </ul>
                            <!-- End List -->
                        </div>
                    </div>
                    <!--// end row -->
                </div>
            </div>
            <!-- End Links -->

        </footer>
        <!--========== END FOOTER ==========-->

        <!-- Back To Top -->
        <a href="javascript:void(0);" class="js-back-to-top back-to-top">Top</a>

        <!-- JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
        <!-- CORE PLUGINS -->
        <script src="vendor/jquery.min.js" type="text/javascript"></script>
        <script src="vendor/jquery-migrate.min.js" type="text/javascript"></script>
        <script src="vendor/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>

        <!-- PAGE LEVEL PLUGINS -->
        <script src="vendor/jquery.easing.js" type="text/javascript"></script>
        <script src="vendor/jquery.back-to-top.js" type="text/javascript"></script>
        <script src="vendor/jquery.smooth-scroll.js" type="text/javascript"></script>
        <script src="vendor/jquery.wow.min.js" type="text/javascript"></script>
        <script src="vendor/swiper/js/swiper.jquery.min.js" type="text/javascript"></script>
        <script src="vendor/magnific-popup/jquery.magnific-popup.min.js" type="text/javascript"></script>
        <script src="vendor/masonry/jquery.masonry.pkgd.min.js" type="text/javascript"></script>
        <script src="vendor/masonry/imagesloaded.pkgd.min.js" type="text/javascript"></script>
        
</body>
	<!--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCefOgb1ZWqYtj7raVSmN4PL2WkTrc-KyA&sensor=false"></script>-->

        <!--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCLFNPr5K1NFx4UgfDtxwpDh1qjRNzFl34&callback=initMap;"></script>-->
       <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCLFNPr5K1NFx4UgfDtxwpDh1qjRNzFl34&ampcallback=initMap;v=3.exp&libraries=places"></script>

        <!-- PAGE LEVEL SCRIPTS -->
        <script src="js/layout.min.js" type="text/javascript"></script>
        <script src="js/components/wow.min.js" type="text/javascript"></script>
        <script src="js/components/swiper.min.js" type="text/javascript"></script>
        <script src="js/components/maginific-popup.min.js" type="text/javascript"></script>
        <script src="js/components/masonry.min.js" type="text/javascript"></script>
        <script src="js/components/gmap.min.js" type="text/javascript"></script>
				<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>   	
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
 		<script src="js/google_map.js" type="text/javascript"></script>
 		<script src="js/script.js" type="text/javascript"></script>
				
    </body>
    <!-- END BODY -->
</html>